@echo off
title 人力資源薪資系統
cd /d "%~dp0"
start "" "人力資源薪資系統.html"
