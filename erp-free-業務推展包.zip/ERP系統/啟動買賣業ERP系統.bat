@echo off
title 買賣業ERP系統
cd /d "%~dp0"
start "" "買賣業ERP系統.html"
